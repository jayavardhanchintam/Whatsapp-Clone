//   oW5W2Pupo2sMKGod

// importing
import express from 'express';
import mongoose from 'mongoose';
import Messages from './dbMessages.js';
import Pusher from 'pusher';
import cors from 'cors';

// app config
const app= express();   // allows us to api routes
const port = process.env.PORT || 3000;

const pusher = new Pusher({
    appId: "1473268",
    key: "f48a9f70d15615d48199",
    secret: "9af9084ff7c7a04b26e1",
    cluster: "ap2",
    useTLS: true
  });



// middleware
app.use(express.json());
app.use(cors());





//db config
const connection_url = 'mongodb+srv://admin:oW5W2Pupo2sMKGod@cluster0.ne0d7nv.mongodb.net/?retryWrites=true&w=majority'
mongoose.connect(connection_url, {
    useNewUrlParser: true, 
    useUnifiedTopology: true 
    }, err => {
    if(err) throw err;
    console.log('Connected to MongoDB!!!')
});
const db = mongoose.connection

db.once('open',() => {
    console.log('DB is conncted ly');

    const msgCollection = db.collection("messagecontents");
    const changeStream = msgCollection.watch();

    changeStream.on('change',(change) => {
        console.log(change);

        if(change.operationType === "insert") {
            const messageDetails = change.fullDocument;
            pusher.trigger("messages","inserted", {
                name : messageDetails.name,
                message: messageDetails.message,
                timestamp : messageDetails.timestamp,
                received : messageDetails.received,
            });
        } else {
            console.log("ERROR TRIGGERING PUSHER");
        }
    })
})


//????

//api routes
app.get('/',(req,res)=> res.status(200).send('hello world'));

app.get("/messages/sync", (req,res) => {

    Messages.find((err,data) => {
        if(err){
            res.status(500).send(err)
        } else {
            res.status(200).send(data)
        }
    });
});

app.post("/messages/new", (req,res) => {
    const dbMessage = req.body;

    Messages.create(dbMessage,(err,data) => {
        if(err){
            res.status(500).send(err)
        } else {
            res.status(201).send(data)
        }
    });
});

// listener
app.listen(port,()=>  console.log(`Listening on localhost:${port}`));